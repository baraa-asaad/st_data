package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.model.ExtractionTask
import com.example.data.model.TaskRow
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader

object CsvExcelUtils {

    data class ParsedFileData(
        val fileName: String,
        val headers: List<String>,
        val rows: List<Map<String, String>>
    )

    fun parseCsvFromUri(context: Context, uri: Uri): ParsedFileData? {
        return try {
            val contentResolver = context.contentResolver
            val fileName = getFileName(context, uri) ?: "imported_file.csv"
            
            contentResolver.openInputStream(uri)?.use { inputStream ->
                val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
                val lines = reader.readLines().filter { it.isNotBlank() }
                if (lines.isEmpty()) return null

                val delimiter = detectDelimiter(lines.first())
                val headers = parseCsvLine(lines.first(), delimiter).map { it.trim() }

                val dataRows = mutableListOf<Map<String, String>>()
                for (i in 1 until lines.size) {
                    val tokens = parseCsvLine(lines[i], delimiter)
                    val rowMap = mutableMapOf<String, String>()
                    headers.forEachIndexed { index, header ->
                        val value = if (index < tokens.size) tokens[index].trim() else ""
                        rowMap[header] = value
                    }
                    if (rowMap.values.any { it.isNotEmpty() }) {
                        dataRows.add(rowMap)
                    }
                }

                ParsedFileData(fileName, headers, dataRows)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun generateSampleStudentCsv(context: Context): ParsedFileData {
        val fileName = "نموذج_بيانات_الطلاب.csv"
        val headers = listOf("رقم الهوية", "سنة الميلاد", "الاسم المبدئي", "ملاحظات")
        val sampleData = listOf(
            mapOf("رقم الهوية" to "900123456", "سنة الميلاد" to "2006", "الاسم المبدئي" to "طالب تجريبي 1", "ملاحظات" to "غزة"),
            mapOf("رقم الهوية" to "900123457", "سنة الميلاد" to "2006", "الاسم المبدئي" to "طالب تجريبي 2", "ملاحظات" to "رفح"),
            mapOf("رقم الهوية" to "900123458", "سنة الميلاد" to "2005", "الاسم المبدئي" to "طالب تجريبي 3", "ملاحظات" to "الوسطى"),
            mapOf("رقم الهوية" to "900123459", "سنة الميلاد" to "2007", "الاسم المبدئي" to "طالب تجريبي 4", "ملاحظات" to "خان يونس"),
            mapOf("رقم الهوية" to "900123460", "سنة الميلاد" to "2006", "الاسم المبدئي" to "طالب تجريبي 5", "ملاحظات" to "الشمال")
        )
        return ParsedFileData(fileName, headers, sampleData)
    }

    fun exportTaskResultsToCsv(
        context: Context,
        task: ExtractionTask,
        rows: List<TaskRow>
    ): File? {
        return try {
            val baseName = task.sourceFileName.substringBeforeLast(".")
            val exportFileName = "${baseName}_نتائج.csv"
            
            val exportsDir = File(context.getExternalFilesDir(null), "Exports")
            if (!exportsDir.exists()) exportsDir.mkdirs()

            val exportFile = File(exportsDir, exportFileName)
            
            // Extract unique dynamic response keys
            val allExtractedKeys = mutableSetOf<String>()
            rows.forEach { row ->
                try {
                    val json = JSONObject(row.extractedDataJson)
                    json.keys().forEach { key -> allExtractedKeys.add(key) }
                } catch (ignored: Exception) {}
            }

            // Fallback expected headers if empty
            if (allExtractedKeys.isEmpty()) {
                task.extractionFieldsJson.split(",").forEach { field ->
                    if (field.isNotBlank()) allExtractedKeys.add(field.trim())
                }
            }

            val headerRow = mutableListOf(
                "رقم الصف",
                task.idColumnName,
                task.yearColumnName,
                "الحالة",
                "رمز HTTP",
                "مدة الطلب (مللي ثانية)"
            )
            headerRow.addAll(allExtractedKeys)
            headerRow.add("تفاصيل الخطأ")

            FileOutputStream(exportFile).use { fos ->
                // Add UTF-8 BOM so Excel displays Arabic correctly
                fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                
                // Write Header
                val headerLine = headerRow.joinToString(",") { escapeCsv(it) } + "\n"
                fos.write(headerLine.toByteArray(Charsets.UTF_8))

                // Write Data Rows
                rows.forEach { row ->
                    val lineTokens = mutableListOf<String>()
                    lineTokens.add(row.rowIndex.toString())
                    lineTokens.add(row.idValue)
                    lineTokens.add(row.yearValue)
                    lineTokens.add(row.status)
                    lineTokens.add(row.httpStatusCode.toString())
                    lineTokens.add(row.executionDurationMs.toString())

                    val extractedJson = try { JSONObject(row.extractedDataJson) } catch (e: Exception) { JSONObject() }
                    allExtractedKeys.forEach { key ->
                        val value = extractedJson.optString(key, "")
                        lineTokens.add(value)
                    }

                    lineTokens.add(row.errorMessage ?: "")

                    val rowLine = lineTokens.joinToString(",") { escapeCsv(it) } + "\n"
                    fos.write(rowLine.toByteArray(Charsets.UTF_8))
                }
            }

            exportFile
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun detectDelimiter(line: String): Char {
        return when {
            line.contains("\t") -> '\t'
            line.contains(";") -> ';'
            else -> ','
        }
    }

    private fun parseCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuotes = false

        for (ch in line) {
            if (ch == '"') {
                inQuotes = !inQuotes
            } else if (ch == delimiter && !inQuotes) {
                result.add(sb.toString())
                sb.clear()
            } else {
                sb.append(ch)
            }
        }
        result.add(sb.toString())
        return result
    }

    private fun escapeCsv(value: String): String {
        val clean = value.replace("\n", " ").replace("\r", " ")
        return if (clean.contains(",") || clean.contains("\"") || clean.contains(";")) {
            "\"" + clean.replace("\"", "\"\"") + "\""
        } else {
            clean
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex("_display_name")
                    if (nameIndex != -1) {
                        result = cursor.getString(nameIndex)
                    }
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }
}
