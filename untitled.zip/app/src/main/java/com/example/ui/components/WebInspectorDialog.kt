package com.example.ui.components

import android.graphics.Bitmap
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.EmeraldSuccess
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WebInspectorDialog(
    initialUrl: String,
    initialIdParam: String,
    initialYearParam: String,
    initialFieldsCsv: String,
    onApplySettings: (targetUrl: String, idParamKey: String, yearParamKey: String, extractionFieldsCsv: String, method: String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var urlText by remember { mutableStateOf(initialUrl.ifBlank { "https://emis.unrwa.org/Result/StudentsResult" }) }
    var currentLoadedUrl by remember { mutableStateOf(urlText) }
    var isLoadingPage by remember { mutableStateOf(false) }

    var detectedInputs by remember { mutableStateOf<List<String>>(emptyList()) }
    var idParamKey by remember { mutableStateOf(initialIdParam.ifBlank { "IdNumber" }) }
    var yearParamKey by remember { mutableStateOf(initialYearParam.ifBlank { "BirthYear" }) }
    var testIdValue by remember { mutableStateOf("900123456") }
    var testYearValue by remember { mutableStateOf("2006") }

    var testResponseBodySnippet by remember { mutableStateOf("") }
    var extractedFieldsList by remember {
        mutableStateOf(
            if (initialFieldsCsv.isNotBlank()) initialFieldsCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
            else mutableListOf("اسم الطالب", "النتيجة", "المعدل", "الصف", "المدرسة")
        )
    }
    var newFieldInput by remember { mutableStateOf("") }

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var activeTab by remember { mutableIntStateOf(0) } // 0: WebView, 1: Field Mapping & Results

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Top Header Bar
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "معاين ومفتش المواقع التفاعلي",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تحديد الخانات، الاستعلام المباشر، وتعيين بيانات الاستخراج",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    },
                    actions = {
                        Button(
                            onClick = {
                                onApplySettings(
                                    currentLoadedUrl,
                                    idParamKey,
                                    yearParamKey,
                                    extractedFieldsList.joinToString(","),
                                    "POST"
                                )
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("اعتماد وتطبيق", fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )

                // URL Address Bar & Actions
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .padding(8.dp)
                            .fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = urlText,
                            onValueChange = { urlText = it },
                            placeholder = { Text("أدخل رابط الموقع المستهدف...") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            trailingIcon = {
                                if (isLoadingPage) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                }
                            }
                        )

                        Button(
                            onClick = {
                                var formatted = urlText.trim()
                                if (!formatted.startsWith("http://") && !formatted.startsWith("https://")) {
                                    formatted = "https://$formatted"
                                    urlText = formatted
                                }
                                webViewInstance?.loadUrl(formatted)
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "تحميل")
                        }
                    }
                }

                // Sub-Nav Tabs: Live View vs Form Inspector
                TabRow(selectedTabIndex = activeTab) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        text = { Text("المعاينة المباشرة (WebView)") },
                        icon = { Icon(imageVector = Icons.Default.Web, contentDescription = null) }
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        text = { Text("الخانات وعناوين البيانات") },
                        icon = { Icon(imageVector = Icons.Default.Tune, contentDescription = null) }
                    )
                }

                // Tab Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (activeTab == 0) {
                        // Embedded Interactive WebView
                        AndroidView(
                            factory = { ctx ->
                                WebView(ctx).apply {
                                    settings.javaScriptEnabled = true
                                    settings.domStorageEnabled = true
                                    settings.useWideViewPort = true
                                    settings.loadWithOverviewMode = true

                                    webViewClient = object : WebViewClient() {
                                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                            isLoadingPage = true
                                            url?.let { currentLoadedUrl = it }
                                        }

                                        override fun onPageFinished(view: WebView?, url: String?) {
                                            isLoadingPage = false
                                            url?.let { currentLoadedUrl = it }

                                            // Auto extract input element names via JS
                                            val jsDetect = """
                                                (function() {
                                                    var inputs = document.querySelectorAll('input, select');
                                                    var names = [];
                                                    for (var i = 0; i < inputs.length; i++) {
                                                        var n = inputs[i].name || inputs[i].id || inputs[i].placeholder;
                                                        if (n) names.push(n);
                                                    }
                                                    return JSON.stringify(names);
                                                })();
                                            """.trimIndent()

                                            view?.evaluateJavascript(jsDetect) { jsonResult ->
                                                try {
                                                    val cleanJson = jsonResult?.removeSurrounding("\"")?.replace("\\\"", "\"")
                                                    if (!cleanJson.isNullOrBlank() && cleanJson.startsWith("[")) {
                                                        val jsonArr = JSONArray(cleanJson)
                                                        val list = mutableListOf<String>()
                                                        for (i in 0 until jsonArr.length()) {
                                                            list.add(jsonArr.getString(i))
                                                        }
                                                        detectedInputs = list
                                                    }
                                                } catch (e: Exception) {
                                                    e.printStackTrace()
                                                }
                                            }
                                        }
                                    }

                                    loadUrl(urlText)
                                    webViewInstance = this
                                }
                            },
                            update = { webView ->
                                webViewInstance = webView
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Configuration & Inspection Tab
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Section: Form Inputs Mapping
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "1. الخانات المكتشفة من الصفحة الحالية",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )

                                    if (detectedInputs.isNotEmpty()) {
                                        Text(text = "الخانات المكتشفة تلقائياً:", fontSize = 12.sp)
                                        FlowRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            detectedInputs.forEach { inputName ->
                                                SuggestionChip(
                                                    onClick = {
                                                        if (inputName.lowercase().contains("year") || inputName.contains("سنة") || inputName.contains("birth")) {
                                                            yearParamKey = inputName
                                                        } else {
                                                            idParamKey = inputName
                                                        }
                                                    },
                                                    label = { Text(inputName) }
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedTextField(
                                            value = idParamKey,
                                            onValueChange = { idParamKey = it },
                                            label = { Text("اسم معامل الهوية (ID Key)") },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp)
                                        )

                                        OutlinedTextField(
                                            value = yearParamKey,
                                            onValueChange = { yearParamKey = it },
                                            label = { Text("اسم معامل سنة الميلاد (Year Key)") },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                    }

                                    // Auto Fill & Submit Test Button
                                    Button(
                                        onClick = {
                                            val fillJs = """
                                                (function() {
                                                    var idEl = document.querySelector('input[name="$idParamKey"], input[id="$idParamKey"], input[placeholder*="هوية"], input[placeholder*="ID"]');
                                                    if (idEl) idEl.value = "$testIdValue";
                                                    
                                                    var yrEl = document.querySelector('input[name="$yearParamKey"], input[id="$yearParamKey"], input[placeholder*="سنة"], input[placeholder*="Year"]');
                                                    if (yrEl) yrEl.value = "$testYearValue";
                                                    
                                                    var btn = document.querySelector('button[type="submit"], input[type="submit"], button.btn, input.btn');
                                                    if (btn) { btn.click(); return "Submitted"; }
                                                    var form = document.querySelector('form');
                                                    if (form) { form.submit(); return "Form Submitted"; }
                                                    return "Filled";
                                                })();
                                            """.trimIndent()

                                            webViewInstance?.evaluateJavascript(fillJs) { res ->
                                                activeTab = 0 // Switch back to webview to see submit
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("تعبئة وقيم اختبارية وإرسال الاستعلام الآن")
                                    }
                                }
                            }

                            // Section: Extraction Fields Customizer
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Text(
                                        text = "2. عناوين البيانات المطلوب استخراجها من النتيجة",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleMedium
                                    )

                                    Text(
                                        text = "سيعمل التطبيق على البحث عن هذه العناوين في صفحة النتائج وتصدير قيمها في أعمدة Excel:",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        extractedFieldsList.forEach { field ->
                                            InputChip(
                                                selected = true,
                                                onClick = {
                                                    extractedFieldsList = extractedFieldsList.toMutableList().apply { remove(field) }
                                                },
                                                label = { Text(field) },
                                                trailingIcon = {
                                                    Icon(
                                                        imageVector = Icons.Default.Close,
                                                        contentDescription = "حذف",
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = newFieldInput,
                                            onValueChange = { newFieldInput = it },
                                            placeholder = { Text("إضافة عنوان آخر (مثلاً: رقم الجلوس)") },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(10.dp),
                                            singleLine = true
                                        )

                                        Button(
                                            onClick = {
                                                if (newFieldInput.isNotBlank() && !extractedFieldsList.contains(newFieldInput.trim())) {
                                                    extractedFieldsList = extractedFieldsList.toMutableList().apply { add(newFieldInput.trim()) }
                                                    newFieldInput = ""
                                                }
                                            },
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Add, contentDescription = "إضافة")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
