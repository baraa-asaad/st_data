package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Web
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.WebInspectorDialog
import com.example.ui.viewmodel.DataExtractorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportSetupScreen(
    viewModel: DataExtractorViewModel,
    onStartBatchClicked: () -> Unit,
    modifier: Modifier = Modifier
) {
    val parsedData by viewModel.parsedFileData.collectAsState()

    val taskName by viewModel.taskNameInput.collectAsState()
    val targetUrl by viewModel.targetUrlInput.collectAsState()
    val requestMethod by viewModel.requestMethodInput.collectAsState()
    val idColumn by viewModel.idColumnInput.collectAsState()
    val yearColumn by viewModel.yearColumnInput.collectAsState()
    val idParam by viewModel.idParamInput.collectAsState()
    val yearParam by viewModel.yearParamInput.collectAsState()
    val extractionFields by viewModel.extractionFieldsInput.collectAsState()
    val delayMillis by viewModel.delayMillisInput.collectAsState()
    val concurrency by viewModel.concurrencyInput.collectAsState()

    var showInspectorDialog by remember { mutableStateOf(false) }

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadCsvFromUri(it) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section 1: File Import Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = "استيراد",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "1. استيراد الملف البيانات (CSV / Excel)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { filePickerLauncher.launch("*/*") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("اختر ملف CSV / Excel")
                    }

                    OutlinedButton(
                        onClick = { viewModel.loadSampleData() },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ملف تجريبي")
                    }
                }

                parsedData?.let { data ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "الملف المحدد: ${data.fileName}",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "عدد الصفوف: ${data.rows.size} | الأعمدة المكتشفة: ${data.headers.joinToString(", ")}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }
        }

        // Section 2: Endpoint & Target Settings Card
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "2. إعدادات الخادم والربط (Target API)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                OutlinedTextField(
                    value = taskName,
                    onValueChange = { viewModel.taskNameInput.value = it },
                    label = { Text("اسم عملية الفحص") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = targetUrl,
                    onValueChange = { viewModel.targetUrlInput.value = it },
                    label = { Text("رابط الموقع أو المستهدف (Target URL)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                // Interactive Web Inspector Button
                Button(
                    onClick = { showInspectorDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Web, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("معاينة وتحديد الخانات من المتصفح التفاعلي", fontWeight = FontWeight.Bold)
                }

                // Request Method Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "نوع الطلب:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    FilterChip(
                        selected = requestMethod == "POST",
                        onClick = { viewModel.requestMethodInput.value = "POST" },
                        label = { Text("POST (Form)") }
                    )
                    FilterChip(
                        selected = requestMethod == "GET",
                        onClick = { viewModel.requestMethodInput.value = "GET" },
                        label = { Text("GET (URL Query)") }
                    )
                }

                Divider()

                // Column & Parameter Mappings
                Text(text = "مطابقة عمود الملف مع معامل الموقع:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                val headers = parsedData?.headers ?: listOf("رقم الهوية", "سنة الميلاد")

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "عمود الهوية في الملف", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        DropdownSelector(
                            options = headers,
                            selectedOption = idColumn,
                            onOptionSelected = { viewModel.idColumnInput.value = it }
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "اسم معامل الهوية (Key)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(
                            value = idParam,
                            onValueChange = { viewModel.idParamInput.value = it },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "عمود سنة الميلاد في الملف", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        DropdownSelector(
                            options = headers,
                            selectedOption = yearColumn,
                            onOptionSelected = { viewModel.yearColumnInput.value = it }
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "اسم معامل السنة (Key)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedTextField(
                            value = yearParam,
                            onValueChange = { viewModel.yearParamInput.value = it },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = extractionFields,
                    onValueChange = { viewModel.extractionFieldsInput.value = it },
                    label = { Text("عناوين البيانات المطلوب استخراجها (مفصولة بفاصلة)") },
                    supportingText = { Text("مثال: اسم الطالب, النتيجة, المعدل, الصف, المدرسة") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                // Performance & Throttling Controls
                Divider()
                Text(text = "إعدادات الأداء وتفادي الحظر:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

                Column {
                    Text(text = "التأخير بين الطلبات: $delayMillis ms", fontSize = 12.sp)
                    Slider(
                        value = delayMillis.toFloat(),
                        onValueChange = { viewModel.delayMillisInput.value = it.toLong() },
                        valueRange = 0f..2000f,
                        steps = 19
                    )
                }

                Column {
                    Text(text = "الاتصالات المتوازية (Concurrency): $concurrency طلبات بنفس الوقت", fontSize = 12.sp)
                    Slider(
                        value = concurrency.toFloat(),
                        onValueChange = { viewModel.concurrencyInput.value = it.toInt() },
                        valueRange = 1f..10f,
                        steps = 8
                    )
                }
            }
        }

        // Action Button: Start Batch
        Button(
            onClick = {
                viewModel.createAndStartTask()
                onStartBatchClicked()
            },
            enabled = parsedData != null,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "بدء الفحص واستخراج البيانات", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }

    if (showInspectorDialog) {
        WebInspectorDialog(
            initialUrl = targetUrl,
            initialIdParam = idParam,
            initialYearParam = yearParam,
            initialFieldsCsv = extractionFields,
            onApplySettings = { url, idKey, yearKey, fieldsCsv, method ->
                viewModel.updateConfigFromInspector(url, idKey, yearKey, fieldsCsv, method)
            },
            onDismiss = { showInspectorDialog = false }
        )
    }
}

@Composable
fun DropdownSelector(
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text(text = selectedOption.ifBlank { "اختر العمود" }, maxLines = 1)
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(text = option) },
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
